<template>
    <div class="chart-container">
        <div class="flex justify-between items-end h-full relative">
            <div v-for="(month, index) in months" :key="index" class="chart-bar"
                :style="{ height: `${month.height}%`, left: `${1 + (index * 8.3)}%` }" :data-month="month.name"
                :data-value="month.value" @mouseover="showTooltip($event, month)" @mouseout="hideTooltip">
            </div>
        </div>

        <div v-if="tooltip.show" class="bg-gray-800 text-white px-2 py-1 rounded text-xs absolute z-10"
            :style="{ bottom: `${tooltip.bottom}px`, left: `${tooltip.left}px`, transform: 'translateX(-50%)' }">
            {{ tooltip.text }}
        </div>
    </div>
    <div class="flex justify-between text-xs text-gray-500 mt-2 px-2 relative z-10">
        <span v-for="(month, index) in months" :key="'label-' + index" class="month-label w-[4%] text-center block">
            {{ month.name }}
        </span>
    </div>
</template>

<script setup>
import { ref, onMounted } from 'vue'
import { useNuxtApp } from '#app'

const { $api } = useNuxtApp()

const months = ref([])
const tooltip = ref({
    show: false,
    text: '',
    bottom: 0,
    left: 0
})

const fetchMonthlyData = async () => {
    try {
        const res = await $api.get('/dashboard/teknisi/monthly')
        months.value = res.data
    } catch (err) {
        console.error('Gagal mengambil data grafik bulanan:', err)
    }
}

const showTooltip = (event, month) => {
    tooltip.value = {
        show: true,
        text: `${month.name}: ${month.value}`,
        bottom: month.height + 10,
        left: event.target.offsetLeft + (event.target.offsetWidth / 2)
    }
}

const hideTooltip = () => {
    tooltip.value.show = false
}

onMounted(fetchMonthlyData)
</script>
