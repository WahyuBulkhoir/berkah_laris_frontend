<template>
    <svg fill="currentColor" viewBox="0 0 24 24" class="w-full h-full">
        <path
            d="M19 10v9H5V5h9V3H5c-1.1 0-2 .9-2 2v14c0 1.1.9 2 2 2h14c1.1 0 2-.9 2-2v-9h-2zm-5 0v5.59l-2.29-2.3-1.42 1.42L15 19.41l4.71-4.7-1.42-1.42L16 15.59V10h-2z">
        </path>
    </svg>
</template>
