<template>
    <svg fill="currentColor" viewBox="0 0 24 24" class="w-full h-full">
        <path
            d="M21 5H3a1 1 0 0 0-1 1v12a1 1 0 0 0 1 1h18a1 1 0 0 0 1-1V6a1 1 0 0 0-1-1zm-1 11H4V7h16v9zm-8-3a2 2 0 1 0 0-4 2 2 0 0 0 0 4z">
        </path>
    </svg>
</template>
